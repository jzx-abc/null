package com.homework.controller;

import com.homework.service.CartService;
import com.homework.service.impl.CartServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
@WebServlet("/deleteCart")
public class DeleteCartController extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        String productId = req.getParameter("productId");
        CartService cs = new CartServiceImpl();
        cs.deleteCart(Integer.parseInt(productId));
        resp.sendRedirect("/FinalHomeWork/showAllCart");
    }
}
