package com.homework.controller;

import com.homework.entity.Product;
import com.homework.service.CartService;
import com.homework.service.impl.CartServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
@WebServlet("/addCart")
public class AddCartController extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //req.setCharacterEncoding("uft-8");
        String productId = req.getParameter("productId");
        String productName = req.getParameter("productName");
        String productPrice = req.getParameter("productPrice");
        String productStore = req.getParameter("productStore");
        String productDescription = req.getParameter("productDescription");
        Product product = new Product(Integer.parseInt(productId),productName,Double.parseDouble(productPrice),Integer.parseInt(productStore),productDescription);
        System.out.println(product);
        String id = req.getParameter("userId");
        System.out.println(id);
        CartService cs = new CartServiceImpl();
        cs.addCart(product,id);
        //resp.sendRedirect("/FinalHomeWork/showAllCart");
        resp.sendRedirect("/FinalHomeWork/showAllProduct");

    }
}
