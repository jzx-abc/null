package com.homework.controller;

import com.homework.entity.Product;
import com.homework.service.ProductService;
import com.homework.service.impl.ProductServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet("/deleteProductById")
public class DeleteProductByIdController extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        String s = req.getParameter("id");
        int id = Integer.parseInt(s);
        ProductService ps = new ProductServiceImpl();
        ps.deleteProductById(id);
//        //重新遍历product表
//        List<Product> list = ps.showAllProduct();
//        HttpSession session = req.getSession();
//        session.setAttribute("list",list);
//        //重定向到productList.jsp页面
//        req.getRequestDispatcher("/product/productList.jsp").forward(req,resp);

        //因为写了showAllProductController,所以在删除了一个物品之后，可以跳转到showAllProductController中
        resp.sendRedirect("/FinalHomeWork/showAllProduct");
    }
}
