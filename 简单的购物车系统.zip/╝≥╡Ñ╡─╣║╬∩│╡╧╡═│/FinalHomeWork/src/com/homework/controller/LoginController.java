package com.homework.controller;

import com.homework.entity.User;
import com.homework.service.UserService;
import com.homework.service.impl.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
@WebServlet("/login")
public class LoginController extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String validateCode = req.getParameter("validateCode");

        HttpSession session = req.getSession();
        String realCode = (String)session.getAttribute("realcode");
        if(validateCode != null && validateCode.equals(realCode)){
            resp.sendRedirect("/FinalHomeWork/managerLogin.html");
            return;
        }
        UserService us = new UserServiceImpl();
        boolean flag = us.login(username,password);
        if(flag == true){
            //创建session，保存用户名
            session.setAttribute("username",username);
            User user = us.SelectByUsernameAndPassword(username, password);
            session.setAttribute("userId",user.getId());
            //设置登录标识
            session.setAttribute("login",true);
            resp.sendRedirect("/FinalHomeWork/showAllProduct");
        }else{
            resp.sendRedirect("/FinalHomeWork/managerLogin.html");
        }
    }
}

