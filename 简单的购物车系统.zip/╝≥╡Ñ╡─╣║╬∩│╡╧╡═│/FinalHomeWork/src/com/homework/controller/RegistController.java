package com.homework.controller;

import com.homework.entity.User;
import com.homework.service.UserService;
import com.homework.service.impl.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
@WebServlet("/regist")
public class RegistController extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String validateCode = req.getParameter("validateCode");
        //验证验证码
        HttpSession session = req.getSession();
        String realCode = (String)session.getAttribute("realCode");
        if(validateCode != null && !validateCode.equals(realCode)){
            //如果验证码不正确，重定向到注册页面
            resp.sendRedirect("/FinalHomeWork/managerRegist.html");
            return;
        }
        User user = new User(null, username, password);
        UserService us = new UserServiceImpl();
        us.regist(user);
        resp.sendRedirect("/FinalHomeWork/managerLogin.html");
    }
}
