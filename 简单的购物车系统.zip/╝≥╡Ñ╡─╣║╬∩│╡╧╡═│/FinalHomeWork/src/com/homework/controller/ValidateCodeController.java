package com.homework.controller;

import cn.dsna.util.images.ValidateCode;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
@WebServlet("/validateCode")
public class ValidateCodeController extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        ValidateCode validateCode = new ValidateCode(100, 40, 4, 30);
        validateCode.write(resp.getOutputStream());
        System.out.println("验证码为:" + validateCode.getCode().toLowerCase());
        //将验证码保存在session中
        HttpSession session = req.getSession();
        //使用toLowerCase()将验证码转化为小写
        session.setAttribute("realCode", validateCode.getCode().toLowerCase());
    }
}
