package com.homework.controller;

import com.homework.entity.Product;
import com.homework.service.ProductService;
import com.homework.service.impl.ProductServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;
@WebServlet("/showAllProduct")
public class ShowAllProductController extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        Object login = session.getAttribute("login");
        if(login == null){
            resp.sendRedirect("/FinalHomeWork/managerLogin.html");
            return;
        }

        String pageNumberStr = req.getParameter("pageNumber");
        //System.out.println(pageNumberStr);
        int pageNumber = 1;
        int pageSize = 5;
        if(pageNumberStr!=null&&!pageNumberStr.isEmpty()){
            pageNumber=Integer.parseInt(pageNumberStr);
        }

        ProductService ps = new ProductServiceImpl();
        List<Product> list = ps.selectPageProduct((pageNumber-1)*pageSize,pageSize);

        //根据查询总条数，计算总页数
        int totalRows = ps.totalRows();
        int totalPage=totalRows%pageSize==0?totalRows/pageSize:totalRows/pageSize+1;

        req.setAttribute("list",list);
        req.setAttribute("totalPage",totalPage);
        req.getRequestDispatcher("/product/productList.jsp").forward(req,resp);
    }
}
