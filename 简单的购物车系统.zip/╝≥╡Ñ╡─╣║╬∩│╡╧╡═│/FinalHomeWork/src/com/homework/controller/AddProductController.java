package com.homework.controller;

import com.homework.entity.Product;
import com.homework.service.ProductService;
import com.homework.service.impl.ProductServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
@WebServlet("/addProduct")
public class AddProductController extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        String productName = req.getParameter("productName");
        String productPrice = req.getParameter("productPrice");
        String productStore = req.getParameter("productStore");
        String productDescription = req.getParameter("productDescription");
        Product product = new Product(null,productName,Double.parseDouble(productPrice),Integer.parseInt(productStore),productDescription);
        ProductService ps = new ProductServiceImpl();
        ps.addProduct(product);
        resp.sendRedirect("/FinalHomeWork/showAllProduct");
    }
}
