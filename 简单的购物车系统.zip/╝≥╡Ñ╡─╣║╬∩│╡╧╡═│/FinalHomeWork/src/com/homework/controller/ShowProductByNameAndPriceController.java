package com.homework.controller;

import com.homework.entity.Product;
import com.homework.service.ProductService;
import com.homework.service.impl.ProductServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;
@WebServlet("/showProductByCondition")
public class ShowProductByNameAndPriceController extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");

        HttpSession session = req.getSession();
        Object login = session.getAttribute("login");
        if(login == null){
            resp.sendRedirect("/FinalHomeWork/managerLogin.html");
            return;
        }

        String produceName = req.getParameter("productName");
        String operation = req.getParameter("operation");
        String number = req.getParameter("number");

        double productPrice = 0.0;
        if(!number.equals("0")){
            productPrice = Double.parseDouble(number);
        }

        String pageNumberStr = req.getParameter("page");
        int pageNumber = 1;
        int pageSize = 5;
        if(pageNumberStr != null){
            pageNumber = Integer.parseInt(pageNumberStr);
        }

        ProductService ps = new ProductServiceImpl();
        List<Product> productList = ps.selectPageProductByNameAndPrice(produceName,operation,productPrice,(pageNumber-1)*pageSize,pageSize);

        //根据查询总条数，计算总页数
        int totalRows = ps.totalRowsByNameAndPrice(produceName,operation,productPrice);
        int totalPage=totalRows%pageSize==0?totalRows/pageSize:totalRows/pageSize+1;

        req.setAttribute("productName",produceName);
        req.setAttribute("operation",operation);
        req.setAttribute("productPrice",productPrice);

        req.setAttribute("list",productList);
        req.setAttribute("totalPage",totalPage);
        req.getRequestDispatcher("/product/productSearchList.jsp").forward(req,resp);
    }
}
