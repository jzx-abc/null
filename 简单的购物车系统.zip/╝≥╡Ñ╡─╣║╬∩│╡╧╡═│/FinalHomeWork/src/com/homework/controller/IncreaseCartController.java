package com.homework.controller;

import com.homework.service.CartService;
import com.homework.service.impl.CartServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
@WebServlet("/increaseCart")
public class IncreaseCartController extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        String productId = req.getParameter("productId");
//        System.out.println(productId);
//        int id = Integer.parseInt(productId);
        String userId = req.getParameter("userId");
        CartService cs = new CartServiceImpl();
        cs.increaseCart(Integer.parseInt(productId),userId);
        resp.sendRedirect("/FinalHomeWork/showAllCart");
    }
}
