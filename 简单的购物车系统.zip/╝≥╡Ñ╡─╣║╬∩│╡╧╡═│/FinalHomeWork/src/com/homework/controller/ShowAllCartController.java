package com.homework.controller;

import com.homework.entity.Cart;
import com.homework.service.CartService;
import com.homework.service.impl.CartServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;
@WebServlet("/showAllCart")
public class ShowAllCartController extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        Object login = session.getAttribute("login");
        if(login == null){
            resp.sendRedirect("/FinalHomeWork/managerLogin.html");
            return;
        }

        CartService cs = new CartServiceImpl();
        List<Cart> cartList = cs.showAllCart();
        req.setAttribute("cartList",cartList);
        req.getRequestDispatcher("/cart/cartList.jsp").forward(req,resp);
    }
}
