package com.homework.service.impl;

import com.homework.dao.CartDao;
import com.homework.dao.impl.CartDaoImpl;
import com.homework.entity.Cart;
import com.homework.entity.Product;
import com.homework.service.CartService;
import com.homework.util.JDBCUtils;

import java.sql.Connection;
import java.util.List;

public class CartServiceImpl implements CartService {
    CartDao cd = new CartDaoImpl();
    @Override
    public void addCart(Product product, String id) {
        Connection connection = null;
        try{
            connection = JDBCUtils.getConnection();
            connection.setAutoCommit(false);
            cd.addCart(product, id);
            connection.commit();
        }catch (Exception e){
            e.printStackTrace();
            if(connection != null){
                try{
                    connection.rollback();
                }catch (Exception e1){
                    e1.printStackTrace();
                }
            }
        }finally {
            JDBCUtils.close(connection,null,null);
        }
    }

    @Override
    public List<Cart> showAllCart() {
        Connection connection = null;
        List<Cart> cartList = null;
        try{
            connection = JDBCUtils.getConnection();
            connection.setAutoCommit(false);
            cartList = cd.showAllCart();
            connection.commit();
        }catch (Exception e){
            e.printStackTrace();
            if(connection != null){
                try{
                    connection.rollback();
                }catch (Exception e1){
                    e1.printStackTrace();
                }
            }
        }finally {
            JDBCUtils.close(connection,null,null);
        }
        return cartList;
    }

    @Override
    public void deleteCart(int productId) {
        Connection connection = null;
        try{
            connection = JDBCUtils.getConnection();
            connection.setAutoCommit(false);
            cd.deleteCart(productId);
            connection.commit();
        }catch (Exception e){
            e.printStackTrace();
            if(connection != null){
                try{
                    connection.rollback();
                }catch (Exception e1){
                    e1.printStackTrace();
                }
            }
        }finally {
            JDBCUtils.close(connection,null,null);
        }
    }

    @Override
    public void increaseCart(int productId, String userId) {
        Connection connection = null;
        try{
            connection = JDBCUtils.getConnection();
            connection.setAutoCommit(false);
            cd.increaseCart(productId, userId);
            connection.commit();
        }catch (Exception e){
            e.printStackTrace();
            if(connection != null){
                try{
                    connection.rollback();
                }catch (Exception e1){
                    e1.printStackTrace();
                }
            }
        }finally {
            JDBCUtils.close(connection,null,null);
        }
    }

    @Override
    public void decreaseCart(int productId, String userId) {
        Connection connection = null;
        try{
            connection = JDBCUtils.getConnection();
            connection.setAutoCommit(false);
            cd.decreaseCart(productId,userId);
            connection.commit();
        }catch (Exception e){
            e.printStackTrace();
            if(connection != null){
                try{
                    connection.rollback();
                }catch (Exception e1){
                    e1.printStackTrace();
                }
            }
        }finally {
            JDBCUtils.close(connection,null,null);
        }
    }
}
