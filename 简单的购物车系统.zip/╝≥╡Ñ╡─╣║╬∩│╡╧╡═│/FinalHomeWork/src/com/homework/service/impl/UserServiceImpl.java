package com.homework.service.impl;

import com.homework.dao.UserDao;
import com.homework.dao.impl.UserDaoImpl;
import com.homework.entity.User;
import com.homework.service.UserService;
import com.homework.util.JDBCUtils;

import java.sql.Connection;
import java.sql.ResultSet;

public class UserServiceImpl implements UserService {
    private UserDao ud = new UserDaoImpl();

    @Override
    public void regist(User user) {
        Connection connection = null;
        try {
            connection = JDBCUtils.getConnection();
            connection.setAutoCommit(false);
            ud.insert(user);
            connection.commit();
        }catch (Exception e){
            e.printStackTrace();
            if(connection != null){
                try{
                    connection.rollback();
                }catch (Exception e1){
                    e1.printStackTrace();
                }
            }
        }finally {
            JDBCUtils.close(connection, null, null);
        }
    }

    @Override
    public boolean login(String username, String password) {
        Connection connection = null;
        User user = null;
        try{
            connection = JDBCUtils.getConnection();
            connection.setAutoCommit(false);
            user = ud.SelectByUsernameAndPassword(username,password);
            connection.commit();
        }catch (Exception e){
            e.printStackTrace();
            if(connection != null){
                try {
                    connection.rollback();
                }catch (Exception e1){
                    e1.printStackTrace();
                }
            }
        }finally {
            JDBCUtils.close(connection,null,null);
        }
        if(user == null)
            return false;
        return true;
    }

    @Override
    public User SelectByUsernameAndPassword(String username, String password) {
        Connection connection = null;
        User user = null;
        try{
            connection = JDBCUtils.getConnection();
            connection.setAutoCommit(false);
            user = ud.SelectByUsernameAndPassword(username,password);
            connection.commit();
        }catch (Exception e){
            e.printStackTrace();
            if(connection != null){
                try {
                    connection.rollback();
                }catch (Exception e1){
                    e1.printStackTrace();
                }
            }
        }finally {
            JDBCUtils.close(connection,null,null);
        }
        return user;
    }
}
