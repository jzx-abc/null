package com.homework.service.impl;

import com.homework.dao.ProductDao;
import com.homework.dao.impl.ProductDaoImpl;
import com.homework.entity.Product;
import com.homework.service.ProductService;
import com.homework.util.JDBCUtils;

import javax.sql.rowset.JdbcRowSet;
import java.sql.Connection;
import java.util.List;

public class ProductServiceImpl implements ProductService {
    ProductDao pd = new ProductDaoImpl();
    @Override
    public List<Product> showAllProduct() {
        Connection connection = null;
        List<Product> list = null;
        try{
            connection = JDBCUtils.getConnection();
            connection.setAutoCommit(false);
            list = pd.SelectAllProduct();
            connection.commit();
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            JDBCUtils.close(connection,null,null);
        }
        return list;
    }

    @Override
    public void deleteProductById(int id) {
        Connection connection = null;
        try{
            connection = JDBCUtils.getConnection();
            connection.setAutoCommit(false);
            pd.deleteProductById(id);
            connection.commit();
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            JDBCUtils.close(connection,null,null);
        }
    }

    @Override
    public List<Product> selectProductByNameAndPrice(String productName, String operation, double productPrice) {
        Connection connection = null;
        List<Product> productList = null;
        try{
            connection = JDBCUtils.getConnection();
            connection.setAutoCommit(false);
            productList = pd.SelectAllProductByNameAndPrice(productName,operation,productPrice);
            connection.commit();
        }catch (Exception e){
            e.printStackTrace();
            if(connection != null){
                try{
                    connection.rollback();
                }catch (Exception e1){
                    e1.printStackTrace();
                }
            }
        }finally {
            JDBCUtils.close(connection,null,null);
        }
        return productList;
    }

    @Override
    public void updateProduct(int id, String productName, double productPrice, String productDescription) {
        Connection connection = null;
        try{
            connection = JDBCUtils.getConnection();
            connection.setAutoCommit(false);
            pd.updateProduct(id,productName,productPrice,productDescription);
            connection.commit();
        }catch (Exception e){
            e.printStackTrace();
            if(connection != null){
                try{
                    connection.rollback();
                }catch (Exception e1){
                    e1.printStackTrace();
                }
            }
        }finally {
            JDBCUtils.close(connection,null,null);
        }
    }

    @Override
    public Product selectOne(int id) {
        Connection connection = null;
        Product product = null;
        try{
            connection = JDBCUtils.getConnection();
            connection.setAutoCommit(false);
            product = pd.selectOne(id);
            connection.commit();
        }catch (Exception e){
            e.printStackTrace();
            if(connection != null){
                try{
                    connection.rollback();
                }catch (Exception e1){
                    e1.printStackTrace();
                }
            }
        }finally {
            JDBCUtils.close(connection,null,null);
        }
        return product;
    }

    @Override
    public void addProduct(Product product) {
        Connection connection = null;
        try{
            connection = JDBCUtils.getConnection();
            connection.setAutoCommit(false);
            pd.addProduct(product);
            connection.commit();
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            JDBCUtils.close(connection,null,null);
        }
    }

    @Override
    public List<Product> selectPageProduct(int index, int pageSize) {
        Connection connection =null;
        List<Product> list = null;
        try{
            connection = JDBCUtils.getConnection();
            connection.setAutoCommit(false);
            list = pd.selectPageProduct(index,pageSize);
            connection.commit();
        }catch (Exception e){
            e.printStackTrace();
            if(connection != null){
                try{
                    connection.rollback();
                }catch (Exception e1){
                    e1.printStackTrace();
                }
            }
        }finally {
            JDBCUtils.close(connection,null,null);
        }
        return list;
    }

    @Override
    public int totalRows() {
        Connection connection = null;
        int totalRows = 0;
        try{
            connection = JDBCUtils.getConnection();
            connection.setAutoCommit(false);
            totalRows = pd.totalRows();
            connection.commit();
        }catch (Exception e){
            e.printStackTrace();
            if(connection != null){
                try{
                    connection.rollback();
                }catch (Exception e1){
                    e1.printStackTrace();
                }
            }
        }finally {
            JDBCUtils.close(connection,null,null);
        }
        return totalRows;
    }

    @Override
    public List<Product> selectPageProductByNameAndPrice(String productName, String operation, double productPrice, int index, int pageSize) {
        Connection connection = null;
        List<Product> list = null;
        try{
            connection = JDBCUtils.getConnection();
            connection.setAutoCommit(false);
            list = pd.selectPageProductByNameAndPrice(productName, operation, productPrice, index, pageSize);
            connection.commit();
        }catch (Exception e){
            e.printStackTrace();
            if(connection != null){
                try{
                    connection.rollback();
                }catch (Exception e1){
                    e1.printStackTrace();
                }
            }
        }finally {
            JDBCUtils.close(connection,null,null);
        }
        return list;
    }

    @Override
    public int totalRowsByNameAndPrice(String productName, String operation, double productPrice) {
        Connection connection = null;
        int totalRows = 0;
        try{
            connection = JDBCUtils.getConnection();
            connection.setAutoCommit(false);
            totalRows = pd.totalRowsByNameAndPrice(productName, operation, productPrice);
            connection.commit();
        }catch (Exception e){
            e.printStackTrace();
            if(connection != null){
                try{
                    connection.rollback();
                }catch (Exception e1){
                    e1.printStackTrace();
                }
            }
        }finally {
            JDBCUtils.close(connection,null,null);
        }
        return totalRows;
    }
}
