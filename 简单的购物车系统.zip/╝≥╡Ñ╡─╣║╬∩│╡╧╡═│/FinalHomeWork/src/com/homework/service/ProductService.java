package com.homework.service;

import com.homework.entity.Product;

import java.util.List;

public interface ProductService {
    List<Product> showAllProduct();
    void deleteProductById(int id);
    List<Product> selectProductByNameAndPrice(String productName, String operation, double productPrice);
    void updateProduct(int id, String productName, double productPrice, String productDescription);
    Product selectOne(int id);
    void addProduct(Product product);
    List<Product> selectPageProduct(int index, int pageSize);
    int totalRows();
    List<Product> selectPageProductByNameAndPrice(String productName, String operation, double productPrice, int index, int pageSize);
    int totalRowsByNameAndPrice(String productName, String operation, double productPrice);
}
