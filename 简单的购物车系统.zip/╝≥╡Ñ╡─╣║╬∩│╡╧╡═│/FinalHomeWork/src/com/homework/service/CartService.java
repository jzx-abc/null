package com.homework.service;

import com.homework.entity.Cart;
import com.homework.entity.Product;

import java.util.List;

public interface CartService {
    void addCart(Product product, String id);
    List<Cart> showAllCart();
    void deleteCart(int productId);
    void increaseCart(int productId, String userId);
    void decreaseCart(int productId, String userId);
}
