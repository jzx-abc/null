package com.homework.service;

import com.homework.entity.User;

public interface UserService {
    void regist(User user);
    boolean login(String username, String password);
    User SelectByUsernameAndPassword(String username,String password);
}
