package com.homework.entity;

public class Cart {
    private int productId;
    private String cartName;
    private double cartPrice;
    private int cartNumber;
    private double carTotal;
    private String userName;

    public Cart() {
    }

    public Cart(int productId, String cartName, double cartPrice, int cartNumber, double carTotal, String userName) {
        this.productId = productId;
        this.cartName = cartName;
        this.cartPrice = cartPrice;
        this.cartNumber = cartNumber;
        this.carTotal = carTotal;
        this.userName = userName;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getCartName() {
        return cartName;
    }

    public void setCartName(String cartName) {
        this.cartName = cartName;
    }

    public double getCartPrice() {
        return cartPrice;
    }

    public void setCartPrice(double cartPrice) {
        this.cartPrice = cartPrice;
    }

    public int getCartNumber() {
        return cartNumber;
    }

    public void setCartNumber(int cartNumber) {
        this.cartNumber = cartNumber;
    }

    public double getCarTotal() {
        return carTotal;
    }

    public void setCarTotal(double carTotal) {
        this.carTotal = carTotal;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserId(String userName) {
        this.userName = userName;
    }

    @Override
    public String toString() {
        return "Cart{" +
                "productId=" + productId +
                ", cartName='" + cartName + '\'' +
                ", cartPrice=" + cartPrice +
                ", cartNumber=" + cartNumber +
                ", carTotal=" + carTotal +
                ", userId=" + userName +
                '}';
    }
}
