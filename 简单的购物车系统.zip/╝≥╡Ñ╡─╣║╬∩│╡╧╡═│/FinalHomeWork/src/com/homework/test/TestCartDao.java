package com.homework.test;

import com.homework.dao.CartDao;
import com.homework.dao.impl.CartDaoImpl;
import com.homework.entity.Product;
import com.homework.service.CartService;
import com.homework.service.impl.CartServiceImpl;
import org.junit.Test;

public class TestCartDao {
    CartDao cartDao = new CartDaoImpl();
    @Test
    public void testAddCart(){
        Product product = new Product(10,"测试",26.6,10,"good");
        cartDao.addCart(product,"testCode");
    }
    @Test
    public void  testIncreaseCart(){
        //cartDao.increaseCart(17,"testCode");
        CartService cs = new CartServiceImpl();
        int id = 17;
        String userId = "testCode";
        cs.increaseCart(id,userId);
    }
}
