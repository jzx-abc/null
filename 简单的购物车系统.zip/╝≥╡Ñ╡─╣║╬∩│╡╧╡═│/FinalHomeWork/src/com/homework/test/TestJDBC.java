package com.homework.test;

import com.homework.util.JDBCUtils;
import org.junit.Test;

import java.io.IOException;
import java.sql.Connection;

public class TestJDBC {
    @Test
    public void testConn() throws IOException {
        Connection connection = JDBCUtils.getConnection();
        if(connection != null){
            System.out.println("successful!");
        }
    }
}
