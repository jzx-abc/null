package com.homework.test;

import com.homework.entity.Product;
import com.homework.service.ProductService;
import com.homework.service.impl.ProductServiceImpl;
import org.junit.Test;

import java.util.List;

public class TestProductService {
    ProductService ps = new ProductServiceImpl();
    @Test
    public void testShowAllProduct(){
        List<Product> list = ps.showAllProduct();
        for (Product p:list) {
            System.out.println(p);
        }
    }
}
