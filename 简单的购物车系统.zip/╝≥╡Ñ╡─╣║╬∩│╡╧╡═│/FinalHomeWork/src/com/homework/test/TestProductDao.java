package com.homework.test;

import com.homework.dao.ProductDao;
import com.homework.dao.impl.ProductDaoImpl;
import com.homework.entity.Product;
import org.junit.Test;

import java.util.List;

public class TestProductDao {
    ProductDao pd = new ProductDaoImpl();
    @Test
    public void testSelectByConditions(){
        List<Product> productList = pd.SelectAllProductByNameAndPrice("《测试删除4》", "<",120.0);
        for (Product p:
             productList) {
            System.out.println(p);
        }
    }
    @Test
    public void testSelectOne(){
       Product p = pd.selectOne(8);
        System.out.println(p);
    }
    @Test
    public void testSelectPageProduct(){
        List<Product> list = pd.selectPageProduct(0,5);
        for (Product p:
             list) {
            System.out.println(p);
        }
    }
    @Test
    public void testTotalRows(){
        int totalRows = pd.totalRows();
        System.out.println(totalRows);
    }
    @Test
    public void testSelect(){
        List<Product> list = pd.selectPageProductByNameAndPrice("s","0",20,1,5);
        for (Product p:list
             ) {
            System.out.println(p);
        }
    }
}
