package com.homework.test;

import com.homework.entity.User;
import com.homework.service.UserService;
import com.homework.service.impl.UserServiceImpl;
import org.junit.Test;

public class TestUserDaoImpl {
    UserService us = new UserServiceImpl();
    @Test
    public void testSelect (){
        String username = "abc";
        String password = "12345";
        boolean flag = us.login(username, password);
        if(flag == true){
            System.out.println("successful!");
        }else {
            System.out.println("false");
        }
    }
}
