package com.homework.dao;

import com.homework.entity.User;

public interface UserDao {
    void insert(User user);
    User SelectByUsernameAndPassword(String username,String password);
}
