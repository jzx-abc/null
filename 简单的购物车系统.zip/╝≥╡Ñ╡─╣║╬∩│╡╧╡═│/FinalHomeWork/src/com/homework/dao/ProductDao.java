package com.homework.dao;

import com.homework.entity.Product;

import java.util.List;

public interface ProductDao {
    List<Product> SelectAllProduct();
    void deleteProductById(int id);
    List<Product> SelectAllProductByNameAndPrice(String productName, String operation, double productPrice);
    void updateProduct(int id, String productName, double productPrice, String productDescription);
    Product selectOne(int id);
    void addProduct(Product product);
    List<Product> selectPageProduct(int index, int pageSize);
    int totalRows();
    List<Product> selectPageProductByNameAndPrice(String productName, String operation, double productPrice,int index, int pageSize);
    int totalRowsByNameAndPrice(String productName, String operation, double productPrice);
}
