package com.homework.dao;

import com.homework.entity.Cart;
import com.homework.entity.Product;

import java.util.List;

public interface CartDao {
    void addCart (Product product, String id);
    List<Cart> showAllCart();
    void deleteCart(int productId);
    void increaseCart(int productId, String userId);
    void decreaseCart(int productId, String userId);
}
