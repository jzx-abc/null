package com.homework.dao.impl;

import com.homework.dao.CartDao;
import com.homework.entity.Cart;
import com.homework.entity.Product;
import com.homework.util.JDBCUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class CartDaoImpl implements CartDao {
    @Override
    public void addCart(Product product, String id) {
        //合并记录
        Cart cart = null;
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try{
            connection = JDBCUtils.getConnection();
            String sql = "select * from cart where product_id=? and user_id=?";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1,product.getId());
            preparedStatement.setString(2,id);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()){
                int productId = resultSet.getInt("product_id");
                String cartName = resultSet.getString("cart_name");
                double cartPrice = resultSet.getDouble("cart_price");
                int cartNumber = resultSet.getInt("cart_number");
                double cartTotal = resultSet.getDouble("cart_total");
                String userId = resultSet.getString("user_id");
                cart = new Cart(productId,cartName,cartPrice,cartNumber,cartTotal,userId);
            }

            if(cart != null){
                int number = cart.getCartNumber() + 1;
                double price = product.getProduct_price() * number;
                String sql1 = "update cart set cart_number=?,cart_total=? where product_id=? and user_id=?";
                preparedStatement = connection.prepareStatement(sql1);
                preparedStatement.setInt(1,number);
                preparedStatement.setDouble(2,price);
                preparedStatement.setInt(3,product.getId());
                preparedStatement.setString(4,id);
                int i = preparedStatement.executeUpdate();
            }else {
                String sql1 = "insert cart values(?,?,?,?,?,?)";
                preparedStatement = connection.prepareStatement(sql1);
                preparedStatement.setInt(1, product.getId());
                preparedStatement.setString(2, product.getProduct_name());
                preparedStatement.setDouble(3, product.getProduct_price());
                preparedStatement.setInt(4, 1);
                preparedStatement.setDouble(5, product.getProduct_price());
                preparedStatement.setString(6, id);
                int i = preparedStatement.executeUpdate();
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            JDBCUtils.close(null,preparedStatement,null);
        }
    }

    @Override
    public List<Cart> showAllCart() {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        Cart cart = null;
        List<Cart> cartList = new ArrayList<>();
        try{
            connection = JDBCUtils.getConnection();
            String sql = "select * from cart";
            preparedStatement = connection.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()){
                int productId = resultSet.getInt("product_id");
                String cartName = resultSet.getString("cart_name");
                double cartPrice = resultSet.getDouble("cart_price");
                int cartNumber = resultSet.getInt("cart_number");
                double cartTotal = resultSet.getDouble("cart_total");
                String userId = resultSet.getString("user_id");
                cart = new Cart(productId, cartName,cartPrice,cartNumber,cartTotal,userId);
                cartList.add(cart);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return cartList;
    }

    @Override
    public void deleteCart(int productId) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try{
            connection = JDBCUtils.getConnection();
            String sql = "delete from cart where product_id=?";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1,productId);
            int i = preparedStatement.executeUpdate();
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            JDBCUtils.close(null,preparedStatement,null);
        }
    }

    @Override
    public void increaseCart(int productId, String userId) {
        Cart cart = null;
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = JDBCUtils.getConnection();
            String sql = "select * from cart where product_id=? and user_id=?";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, productId);
            preparedStatement.setString(2, userId);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                int id = resultSet.getInt("product_id");
                String cartName = resultSet.getString("cart_name");
                double cartPrice = resultSet.getDouble("cart_price");
                int cartNumber = resultSet.getInt("cart_number");
                double cartTotal = resultSet.getDouble("cart_total");
                String user_id = resultSet.getString("user_id");
                cart = new Cart(id, cartName, cartPrice, cartNumber, cartTotal, user_id);
            }
            if(cart.getCartNumber() > 0){
                int number = cart.getCartNumber()+1;
                double price = cart.getCartPrice() * number;
                String sql1 = "update cart set cart_number=?,cart_total=? where product_id=? and user_id=?";
                preparedStatement = connection.prepareStatement(sql1);
                preparedStatement.setInt(1,number);
                preparedStatement.setDouble(2,price);
                preparedStatement.setInt(3,productId);
                preparedStatement.setString(4,userId);
                int i = preparedStatement.executeUpdate();
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            JDBCUtils.close(null,preparedStatement,resultSet);
        }
    }

    @Override
    public void decreaseCart(int productId, String userId) {
        Cart cart = null;
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = JDBCUtils.getConnection();
            String sql = "select * from cart where product_id=? and user_id=?";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, productId);
            preparedStatement.setString(2, userId);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                int id = resultSet.getInt("product_id");
                String cartName = resultSet.getString("cart_name");
                double cartPrice = resultSet.getDouble("cart_price");
                int cartNumber = resultSet.getInt("cart_number");
                double cartTotal = resultSet.getDouble("cart_total");
                String user_id = resultSet.getString("user_id");
                cart = new Cart(id, cartName, cartPrice, cartNumber, cartTotal, user_id);
            }
            if(cart.getCartNumber()-1 != 0){
                int number = cart.getCartNumber()-1;
                double price = cart.getCartPrice() * number;
                String sql1 = "update cart set cart_number=?,cart_total=? where product_id=? and user_id=?";
                preparedStatement = connection.prepareStatement(sql1);
                preparedStatement.setInt(1,number);
                preparedStatement.setDouble(2,price);
                preparedStatement.setInt(3,productId);
                preparedStatement.setString(4,userId);
                int i = preparedStatement.executeUpdate();
            }else {
                String sql1 = "delete from cart where product_id=? and user_id=?";
                preparedStatement = connection.prepareStatement(sql1);
                preparedStatement.setInt(1,productId);
                preparedStatement.setString(2,userId);
                int i = preparedStatement.executeUpdate();
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            JDBCUtils.close(null,preparedStatement,resultSet);
        }
    }


}
