package com.homework.dao.impl;

import com.homework.dao.ProductDao;
import com.homework.entity.Product;
import com.homework.util.JDBCUtils;
import jdk.nashorn.internal.scripts.JD;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ProductDaoImpl implements ProductDao {
    @Override
    public List<Product> SelectAllProduct() {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        List<Product> list = new ArrayList<>();
        try{
            connection = JDBCUtils.getConnection();
            String sql = "select * from product";
            preparedStatement = connection.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()){
                int product_id = resultSet.getInt("product_id");
                String product_name = resultSet.getString("product_name");
                double product_price = resultSet.getDouble("product_price");
                int product_store = resultSet.getInt("product_store");
                String product_description = resultSet.getString(("product_description"));
                Product product = new Product(product_id, product_name, product_price, product_store, product_description);
                list.add(product);
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            JDBCUtils.close(null, preparedStatement, resultSet);
        }
        return list;
    }

    @Override
    public void deleteProductById(int id) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try{
            connection = JDBCUtils.getConnection();
            String sql = "delete from product where product_id=?";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1,id);
            int i = preparedStatement.executeUpdate();
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            JDBCUtils.close(null,preparedStatement,null);
        }
    }

    @Override
    public List<Product> SelectAllProductByNameAndPrice(String productName, String operation, double productPrice) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        List<Product> productList = new ArrayList<>();
        String sql = null;
        try{
            connection = JDBCUtils.getConnection();
            if(operation.equals("<")){
                sql = "select * from product where product_name=? and product_price<?";
            }else {
                sql = "select * from product where product_name=? and product_price>?";
            }
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1,productName);
            preparedStatement.setDouble(2,productPrice);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()){
                int product_id = resultSet.getInt("product_id");
                String product_name = resultSet.getString("product_name");
                double product_price = resultSet.getDouble("product_price");
                int product_store = resultSet.getInt("product_store");
                String product_description = resultSet.getString(("product_description"));
                Product product = new Product(product_id, product_name, product_price, product_store, product_description);
                productList.add(product);
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            JDBCUtils.close(null,preparedStatement,resultSet);
        }
        return productList;
    }

    @Override
    public void updateProduct(int id, String productName, double productPrice, String productDescription) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try{
            connection = JDBCUtils.getConnection();
            String sql = "update product set product_name=?,product_price=?,product_description=? where product_id=?";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1,productName);
            preparedStatement.setDouble(2,productPrice);
//            preparedStatement.setInt(3,p.getProduct_store());
            preparedStatement.setString(3,productDescription);
            preparedStatement.setInt(4,id);
            int i = preparedStatement.executeUpdate();
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            JDBCUtils.close(null,preparedStatement,null);
        }
    }

    @Override
    public Product selectOne(int id) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        Product product = null;
        try{
            connection = JDBCUtils.getConnection();
            String sql = "select * from product where product_id = ?";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1,id);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()){
                int product_id = resultSet.getInt("product_id");
                String product_name = resultSet.getString("product_name");
                double product_price = resultSet.getDouble("product_price");
                int product_store = resultSet.getInt("product_store");
                String product_description = resultSet.getString(("product_description"));
               product = new Product(product_id, product_name, product_price, product_store, product_description);
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            JDBCUtils.close(null,preparedStatement,resultSet);
        }
        return  product;
    }

    @Override
    public void addProduct(Product product) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try{
            connection = JDBCUtils.getConnection();
            String sql = "insert into product value(null,?,?,?,?)";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1,product.getProduct_name());
            preparedStatement.setDouble(2,product.getProduct_price());
            preparedStatement.setInt(3,product.getProduct_store());
            preparedStatement.setString(4,product.getProduct_description());
            int i = preparedStatement.executeUpdate();
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            JDBCUtils.close(null,preparedStatement,null);
        }
    }

    @Override
    public List<Product> selectPageProduct(int index, int pageSize) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        List<Product> list = new ArrayList<>();
        try{
            connection = JDBCUtils.getConnection();
            String sql = "select * from product limit ?,?";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1,index);
            preparedStatement.setInt(2,pageSize);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()){
                int product_id = resultSet.getInt("product_id");
                String product_name = resultSet.getString("product_name");
                double product_price = resultSet.getDouble("product_price");
                int product_store = resultSet.getInt("product_store");
                String product_description = resultSet.getString(("product_description"));
                Product product = new Product(product_id, product_name, product_price, product_store, product_description);
                list.add(product);
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            JDBCUtils.close(null,preparedStatement,resultSet);
        }
        return list;
    }

    @Override
    public int totalRows() {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        int totalRows = 0;
        try{
            connection = JDBCUtils.getConnection();
            String sql = "select count(*) from product";
            preparedStatement = connection.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()){
                totalRows = resultSet.getInt(1);
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            JDBCUtils.close(null,preparedStatement,resultSet);
        }
        return totalRows;
    }

    @Override
    public List<Product> selectPageProductByNameAndPrice(String productName, String operation, double productPrice, int index, int pageSize) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        List<Product> productList = new ArrayList<>();
        String sql = null;
        try{
            connection = JDBCUtils.getConnection();
            if(operation.equals("<")){
                sql = "select * from product where product_name like concat('%',?,'%') and product_price<? limit ?,?";
                preparedStatement = connection.prepareStatement(sql);
                preparedStatement.setString(1,productName);
                preparedStatement.setDouble(2,productPrice);
                preparedStatement.setInt(3,index);
                preparedStatement.setInt(4,pageSize);
                resultSet = preparedStatement.executeQuery();
            }else if(operation.equals(">")){
                sql = "select * from product where product_name like concat('%',?,'%') and product_price>? limit ?,?";
                preparedStatement = connection.prepareStatement(sql);
                preparedStatement.setString(1,productName);
                preparedStatement.setDouble(2,productPrice);
                preparedStatement.setInt(3,index);
                preparedStatement.setInt(4,pageSize);
                resultSet = preparedStatement.executeQuery();
            }else {
                sql = "select * from product where product_name like concat('%',?,'%') limit ?,?";
                preparedStatement = connection.prepareStatement(sql);
                preparedStatement.setString(1,productName);
                preparedStatement.setInt(2,index);
                preparedStatement.setInt(3,pageSize);
                resultSet = preparedStatement.executeQuery();
            }
            while (resultSet.next()){
                int product_id = resultSet.getInt("product_id");
                String product_name = resultSet.getString("product_name");
                double product_price = resultSet.getDouble("product_price");
                int product_store = resultSet.getInt("product_store");
                String product_description = resultSet.getString(("product_description"));
                Product product = new Product(product_id, product_name, product_price, product_store, product_description);
                productList.add(product);
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            JDBCUtils.close(null,preparedStatement,resultSet);
        }
        return productList;
    }

    @Override
    public int totalRowsByNameAndPrice(String productName, String operation, double productPrice) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        int totalRows = 0;
        try{
            connection = JDBCUtils.getConnection();
            String sql = null;
            if(operation.equals("<")){
                sql = "select count(*) from product where product_name like concat('%',?,'%') and product_price<?";
                preparedStatement = connection.prepareStatement(sql);
                preparedStatement.setString(1,productName);
                preparedStatement.setDouble(2,productPrice);
                resultSet = preparedStatement.executeQuery();
            }else if(operation.equals(">")){
                sql = "select count(*) from product where product_name like concat('%',?,'%') and product_price>?";
                preparedStatement = connection.prepareStatement(sql);
                preparedStatement.setString(1,productName);
                preparedStatement.setDouble(2,productPrice);
                resultSet = preparedStatement.executeQuery();
            }else {
                sql = "select count(*) from product where product_name like concat('%',?,'%')";
                preparedStatement = connection.prepareStatement(sql);
                preparedStatement.setString(1,productName);
                resultSet = preparedStatement.executeQuery();
            }
            while (resultSet.next()){
                totalRows = resultSet.getInt(1);
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            JDBCUtils.close(null,preparedStatement,resultSet);
        }
        return totalRows;
    }
}
